import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { adminRouter } from "./routers/admin";
import { chatRouter } from "./routers/chat";
import { onboardingRouter } from "./routers/onboarding";
import { personalitiesRouter } from "./routers/personalities";
import { subscriptionsRouter } from "./routers/subscriptions"; // Mantido para compatibilidade se necessário
import { licensesRouter } from "./routers/licenses";
import { authRouter } from "./routers/auth";
import { paymentsRouter } from "./routers/payments";

export const appRouter = router({
  system: systemRouter,
  auth: authRouter, // Novo auth router com login por senha
  chat: chatRouter,
  personalities: personalitiesRouter,
  onboarding: onboardingRouter,
  subscriptions: subscriptionsRouter, // Antigo Stripe (descontinuar em breve)
  licenses: licensesRouter, // Novo licenciamento por chaves
  payments: paymentsRouter, // Novo sistema de pagamentos Pix
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
