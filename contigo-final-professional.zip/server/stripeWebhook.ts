import express from "express";
import Stripe from "stripe";
import {
  getSubscriptionByStripeCustomerId,
  updateSubscriptionByStripeSubId,
  upsertSubscription,
} from "./db";

type StripeSubStatus = "active" | "overdue" | "canceled" | "trialing" | "free";

const STATUS_MAP: Record<string, StripeSubStatus> = {
  active: "active",
  trialing: "trialing",
  past_due: "overdue",
  canceled: "canceled",
  unpaid: "overdue",
  incomplete: "overdue",
  incomplete_expired: "canceled",
  paused: "overdue",
};

export function registerStripeWebhook(app: express.Application) {
  app.post(
    "/api/stripe/webhook",
    express.raw({ type: "application/json" }),
    async (req, res) => {
      const stripeKey = process.env.STRIPE_SECRET_KEY;
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

      if (!stripeKey || !webhookSecret) {
        console.warn("[Stripe Webhook] Missing Stripe keys");
        res.status(400).send("Stripe not configured");
        return;
      }

      const stripe = new Stripe(stripeKey, { apiVersion: "2025-02-24.acacia" });
      const sig = req.headers["stripe-signature"] as string;

      let event: Stripe.Event;
      try {
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : "Unknown error";
        console.error("[Stripe Webhook] Signature verification failed:", message);
        res.status(400).send(`Webhook Error: ${message}`);
        return;
      }

      console.log(`[Stripe Webhook] Event: ${event.type}`);

      try {
        switch (event.type) {
          case "checkout.session.completed": {
            const session = event.data.object as Stripe.Checkout.Session;
            if (session.mode === "subscription" && session.subscription && session.customer) {
              const customerId = session.customer as string;
              const subId = session.subscription as string;
              const sub = await stripe.subscriptions.retrieve(subId) as unknown as {
                id: string;
                status: string;
                current_period_end: number;
                cancel_at_period_end: boolean;
                items: { data: Array<{ price: { id: string } }> };
              };

              const existing = await getSubscriptionByStripeCustomerId(customerId);
              if (existing) {
                await upsertSubscription({
                  userId: existing.userId,
                  status: "active",
                  stripeCustomerId: customerId,
                  stripeSubscriptionId: subId,
                  stripePriceId: sub.items.data[0]?.price?.id,
                  currentPeriodEnd: new Date(sub.current_period_end * 1000),
                  cancelAtPeriodEnd: sub.cancel_at_period_end,
                });
              }
            }
            break;
          }

          case "invoice.payment_succeeded": {
            const invoice = event.data.object as Stripe.Invoice & { subscription?: string };
            const subId = invoice.subscription;
            if (subId) {
              const sub = await stripe.subscriptions.retrieve(subId) as unknown as {
                current_period_end: number;
                cancel_at_period_end: boolean;
              };
              await updateSubscriptionByStripeSubId(subId, {
                status: "active",
                currentPeriodEnd: new Date(sub.current_period_end * 1000),
                cancelAtPeriodEnd: sub.cancel_at_period_end,
              });
            }
            break;
          }

          case "invoice.payment_failed": {
            const invoice = event.data.object as Stripe.Invoice & { subscription?: string };
            const subId = invoice.subscription;
            if (subId) {
              await updateSubscriptionByStripeSubId(subId, { status: "overdue" });
            }
            break;
          }

          case "customer.subscription.updated": {
            const sub = event.data.object as Stripe.Subscription & {
              current_period_end: number;
              cancel_at_period_end: boolean;
            };
            const mappedStatus = STATUS_MAP[sub.status] ?? "overdue";
            await updateSubscriptionByStripeSubId(sub.id, {
              status: mappedStatus,
              currentPeriodEnd: new Date(sub.current_period_end * 1000),
              cancelAtPeriodEnd: sub.cancel_at_period_end,
            });
            break;
          }

          case "customer.subscription.deleted": {
            const sub = event.data.object as Stripe.Subscription;
            await updateSubscriptionByStripeSubId(sub.id, {
              status: "canceled",
              cancelAtPeriodEnd: false,
            });
            break;
          }
        }
      } catch (err) {
        console.error("[Stripe Webhook] Handler error:", err);
      }

      res.json({ received: true });
    }
  );
}
