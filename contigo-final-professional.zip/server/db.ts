import { and, desc, eq, sql, gt, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertMessage,
  InsertUser,
  Message,
  User,
  messages,
  personalities,
  users,
  accessKeys,
  licenses,
  payments,
  pixSettings,
  InsertAccessKey,
  InsertLicense,
  InsertPayment,
  InsertPixSetting,
  AccessKey,
  License,
  Payment,
  PixSetting,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { PERSONALITIES } from "@shared/personalities";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod", "passwordHash"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(id: number): Promise<User | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function updateUserOnboarding(
  userId: number,
  data: { displayName: string; age: number; activePersonality: string }
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db
    .update(users)
    .set({ ...data, onboardingDone: true })
    .where(eq(users.id, userId));
}

export async function updateUserPersonality(userId: number, personality: string): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ activePersonality: personality }).where(eq(users.id, userId));
}

export async function getAllUsers(limit = 100, offset = 0): Promise<User[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).limit(limit).offset(offset).orderBy(desc(users.createdAt));
}

export async function adminUpdateUser(
  userId: number,
  data: Partial<InsertUser>
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set(data).where(eq(users.id, userId));
}

// ─── Access Keys & Licenses ──────────────────────────────────────────────────

export async function getAccessKeyByCode(code: string): Promise<AccessKey | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(accessKeys).where(eq(accessKeys.code, code)).limit(1);
  return result[0];
}

export async function useAccessKey(keyId: number, userId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(accessKeys).set({
    status: "used",
    usedByUserId: userId,
    usedAt: new Date(),
    usedCount: sql`${accessKeys.usedCount} + 1`
  }).where(eq(accessKeys.id, keyId));
}

export async function createLicense(data: InsertLicense): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(licenses).values(data);
}

export async function getActiveLicenseByUserId(userId: number): Promise<License | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const now = new Date();
  const result = await db
    .select()
    .from(licenses)
    .where(and(
      eq(licenses.userId, userId),
      eq(licenses.status, "active"),
      gt(licenses.endsAt, now)
    ))
    .limit(1);
  return result[0];
}

export async function getLicenseByUserId(userId: number): Promise<License | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(licenses)
    .where(eq(licenses.userId, userId))
    .orderBy(desc(licenses.endsAt))
    .limit(1);
  return result[0];
}

export async function getAllLicenses(limit = 100, offset = 0): Promise<License[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(licenses).limit(limit).offset(offset).orderBy(desc(licenses.createdAt));
}

export async function createAccessKey(data: InsertAccessKey): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(accessKeys).values(data);
}

export async function getAllAccessKeys(limit = 100, offset = 0): Promise<AccessKey[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(accessKeys).limit(limit).offset(offset).orderBy(desc(accessKeys.createdAt));
}

// ─── Payments & Pix Settings ──────────────────────────────────────────────────

export async function getPixSettings(): Promise<PixSetting | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(pixSettings).where(eq(pixSettings.isActive, true)).limit(1);
  return result[0];
}

export async function upsertPixSettings(data: InsertPixSetting): Promise<void> {
  const db = await getDb();
  if (!db) return;
  const existing = await getPixSettings();
  if (existing) {
    await db.update(pixSettings).set(data).where(eq(pixSettings.id, existing.id));
  } else {
    await db.insert(pixSettings).values(data);
  }
}

export async function createPayment(data: InsertPayment): Promise<Payment> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(payments).values(data);
  const result = await db.select().from(payments).orderBy(desc(payments.createdAt)).limit(1);
  return result[0];
}

export async function getPendingPaymentByUserId(userId: number): Promise<Payment | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(payments)
    .where(and(eq(payments.userId, userId), eq(payments.status, "pending")))
    .limit(1);
  return result[0];
}

export async function getAllPayments(limit = 100, offset = 0): Promise<Payment[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(payments).limit(limit).offset(offset).orderBy(desc(payments.createdAt));
}

export async function approvePayment(paymentId: number, adminId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  
  const payment = (await db.select().from(payments).where(eq(payments.id, paymentId)).limit(1))[0];
  if (!payment || payment.status !== "pending") return;

  await db.update(payments).set({
    status: "paid",
    paidAt: new Date(),
    approvedByAdminId: adminId
  }).where(eq(payments.id, paymentId));

  // Renovar licença
  const license = await getLicenseByUserId(payment.userId);
  const durationDays = 30; // Padrão 30 dias para renovação Pix
  const now = new Date();
  
  if (license) {
    const currentEnd = license.endsAt > now ? license.endsAt : now;
    const newEnd = new Date(currentEnd.getTime() + durationDays * 24 * 60 * 60 * 1000);
    const graceUntil = new Date(newEnd.getTime() + 30 * 24 * 60 * 60 * 1000);
    
    await db.update(licenses).set({
      status: "active",
      endsAt: newEnd,
      graceUntil,
      lastPaymentAt: new Date(),
      updatedAt: new Date()
    }).where(eq(licenses.id, license.id));
  }
}

// ─── Messages ─────────────────────────────────────────────────────────────────

export async function saveMessage(data: InsertMessage): Promise<Message> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(messages).values(data);
  const result = await db
    .select()
    .from(messages)
    .where(and(eq(messages.userId, data.userId), eq(messages.personality, data.personality)))
    .orderBy(desc(messages.createdAt))
    .limit(1);
  return result[0];
}

export async function getMessageHistory(
  userId: number,
  personality: string,
  limit = 30
): Promise<Message[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(messages)
    .where(and(eq(messages.userId, userId), eq(messages.personality, personality)))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
  return rows.reverse();
}

export async function countUserMessages(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(messages)
    .where(eq(messages.userId, userId));
  return result[0]?.count ?? 0;
}

// ─── Personalities ────────────────────────────────────────────────────────────

export async function getAllPersonalities() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(personalities).where(eq(personalities.isActive, true));
}

export async function seedPersonalities(): Promise<void> {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(personalities).limit(1);
  
  // Sempre atualizar/inserir para garantir que a nova personalidade Eli e campos atualizados existam
  for (const p of PERSONALITIES) {
    const data = {
      slug: p.slug,
      name: p.name,
      archetype: p.archetype,
      description: p.description,
      accentColor: p.accentColor,
      systemPrompt: p.systemPrompt,
      isActive: true,
    };
    
    await db.insert(personalities).values(data).onDuplicateKeyUpdate({ set: data });
  }
}
