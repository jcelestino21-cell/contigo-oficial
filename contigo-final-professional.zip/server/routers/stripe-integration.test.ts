import { describe, expect, it } from "vitest";
import { ENV } from "../_core/env";

describe("Stripe Integration", () => {
  it("should have STRIPE_PRICE_ID configured", () => {
    expect(ENV.stripePriceId).toBeDefined();
    expect(ENV.stripePriceId).toMatch(/^price_/);
    expect(ENV.stripePriceId).toBe("price_1TJbq4JMTtS1SSB0J0vSg9QJ");
  });

  it("should have STRIPE_SECRET_KEY configured", () => {
    expect(ENV.stripeSecretKey).toBeDefined();
    expect(ENV.stripeSecretKey).toMatch(/^sk_test_/);
  });

  it("should have STRIPE_WEBHOOK_SECRET configured", () => {
    expect(ENV.stripeWebhookSecret).toBeDefined();
    expect(ENV.stripeWebhookSecret).toMatch(/^whsec_/);
  });

  it("stripe configuration should be complete", () => {
    const hasAllSecrets =
      Boolean(ENV.stripePriceId) &&
      Boolean(ENV.stripeSecretKey) &&
      Boolean(ENV.stripeWebhookSecret);

    expect(hasAllSecrets).toBe(true);
  });
});
