import { describe, expect, it } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createSubscriptionContext(overrides?: Partial<AuthenticatedUser>): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    displayName: "Test",
    age: 25,
    activePersonality: "vicente",
    onboardingDone: true,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("subscriptions router", () => {
  it("should return subscription status for authenticated user", async () => {
    const ctx = createSubscriptionContext();
    const caller = appRouter.createCaller(ctx);

    const status = await caller.subscriptions.status();

    expect(status).toHaveProperty("status");
    expect(status).toHaveProperty("isPremium");
    expect(["active", "free", "overdue", "canceled", "trialing"]).toContain(status.status);
    expect(typeof status.isPremium).toBe("boolean");
  });

  it("should reject unauthenticated users", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    });

    try {
      await caller.subscriptions.status();
      expect.fail("Should have thrown");
    } catch (err: unknown) {
      const error = err as { code?: string };
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should require origin for checkout creation", async () => {
    const ctx = createSubscriptionContext();
    const caller = appRouter.createCaller(ctx);

    try {
      // This will fail if Stripe is not configured, but should validate input
      await caller.subscriptions.createCheckout({
        origin: "https://example.com",
      });
    } catch (err: unknown) {
      const error = err as { code?: string; message?: string };
      // Either INTERNAL_SERVER_ERROR (Stripe not configured) or success
      expect(["INTERNAL_SERVER_ERROR", "FORBIDDEN"]).toContain(error.code);
    }
  });

  it("should require origin for portal creation", async () => {
    const ctx = createSubscriptionContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.subscriptions.createPortal({
        origin: "https://example.com",
      });
    } catch (err: unknown) {
      const error = err as { code?: string };
      // NOT_FOUND or INTERNAL_SERVER_ERROR are expected
      expect(["NOT_FOUND", "INTERNAL_SERVER_ERROR"]).toContain(error.code);
    }
  });
});
