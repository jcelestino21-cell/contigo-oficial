import { z } from "zod";
import { updateUserOnboarding } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const onboardingRouter = router({
  complete: protectedProcedure
    .input(
      z.object({
        displayName: z.string().min(1).max(100),
        age: z.number().int().min(13).max(120),
        activePersonality: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await updateUserOnboarding(ctx.user.id, input);
      return { success: true };
    }),
});
