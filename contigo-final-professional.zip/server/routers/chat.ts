import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { invokeLLM } from "../_core/llm";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getMessageHistory,
  saveMessage,
  getActiveLicenseByUserId,
} from "../db";
import { PERSONALITIES } from "@shared/personalities";

export const chatRouter = router({
  send: protectedProcedure
    .input(
      z.object({
        message: z.string().min(1).max(2000),
        personality: z.string().default("vicente"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { user } = ctx;

      // 1. Verificar licença ativa
      const license = await getActiveLicenseByUserId(user.id);
      
      if (!license) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Sua licença expirou ou não está ativa. Renove para continuar.",
        });
      }

      // 2. Obter prompt da personalidade da fonte única
      const personality = PERSONALITIES.find(p => p.slug === input.personality) || PERSONALITIES.find(p => p.slug === "vicente")!;
      const personalityPrompt = personality.systemPrompt;

      // 3. Obter histórico
      const history = await getMessageHistory(user.id, input.personality, 20);

      // 4. Construir mensagens para o LLM
      const systemMessage = `${personalityPrompt}

Contexto do usuário: ${user.displayName ? `Nome: ${user.displayName}` : ""}${user.age ? `, Idade: ${user.age}` : ""}

Regras absolutas:
- Responda SEMPRE em português brasileiro
- Máximo 4 frases por resposta
- Nunca use frases motivacionais genéricas
- Nunca repita o nome da pessoa
- Nunca diga que é uma IA
- Não encerre a conversa completamente
- Valide a emoção antes de qualquer conselho
- Seja humano, imperfeito, presente`;

      const llmMessages = [
        { role: "system" as const, content: systemMessage },
        ...history.map((m) => ({
          role: m.role as "user" | "assistant",
          content: m.content,
        })),
        { role: "user" as const, content: input.message },
      ];

      // 5. Salvar mensagem do usuário
      await saveMessage({
        userId: user.id,
        personality: input.personality,
        role: "user",
        content: input.message,
      });

      // 6. Chamar LLM
      const response = await invokeLLM({ messages: llmMessages });
      const rawContent = response.choices[0]?.message?.content;
      const aiContent = typeof rawContent === "string" ? rawContent : "...";

      // 7. Salvar resposta da IA
      await saveMessage({
        userId: user.id,
        personality: input.personality,
        role: "assistant",
        content: aiContent,
      });

      return { reply: aiContent };
    }),

  history: protectedProcedure
    .input(
      z.object({
        personality: z.string(),
        limit: z.number().int().min(1).max(100).default(30),
      })
    )
    .query(async ({ ctx, input }) => {
      const { user } = ctx;
      
      // Verificar se a licença está no período de carência (grace period)
      // Se estiver expirada há mais de 30 dias, o histórico poderia ser bloqueado ou arquivado
      // Por enquanto, apenas permitimos a leitura se houver licença ou se estiver no grace period
      const license = await getActiveLicenseByUserId(user.id);
      
      // Nota: getActiveLicenseByUserId deve ser robusta o suficiente para lidar com status e datas
      if (!license) {
         // Se não tem licença ativa, mas o histórico existe, o frontend pode lidar com a mensagem de bloqueio
      }

      return getMessageHistory(user.id, input.personality, input.limit);
    }),

  status: protectedProcedure.query(async ({ ctx }) => {
    const license = await getActiveLicenseByUserId(ctx.user.id);
    return {
      hasActiveLicense: !!license,
      license: license || null,
    };
  }),
});
