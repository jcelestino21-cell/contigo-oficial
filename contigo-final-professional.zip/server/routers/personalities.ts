import { z } from "zod";
import { getAllPersonalities, updateUserPersonality } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const personalitiesRouter = router({
  list: protectedProcedure.query(async () => {
    return getAllPersonalities();
  }),

  select: protectedProcedure
    .input(z.object({ slug: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await updateUserPersonality(ctx.user.id, input.slug);
      return { success: true };
    }),
});
