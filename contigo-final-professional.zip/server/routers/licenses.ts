import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import {
  getAccessKeyByCode,
  useAccessKey,
  createLicense,
  getLicenseByUserId,
  getActiveLicenseByUserId,
  upsertUser,
  getUserByOpenId,
} from "../db";

export const licensesRouter = router({
  // Ativação de chave (Pode ser feita sem estar logado se for a primeira vez)
  activateKey: publicProcedure
    .input(z.object({ 
      code: z.string().min(4),
      openId: z.string().optional(), // Opcional se já estiver logado
    }))
    .mutation(async ({ ctx, input }) => {
      const key = await getAccessKeyByCode(input.code);
      
      if (!key || key.status !== "new") {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Chave inválida ou já utilizada.",
        });
      }

      // Se o usuário já estiver logado, usamos o ID dele
      let userId = ctx.user?.id;

      // Se não estiver logado, precisamos de um identificador (openId)
      if (!userId && input.openId) {
        const user = await getUserByOpenId(input.openId);
        if (user) {
          userId = user.id;
        } else {
          // Criar usuário temporário ou aguardar criação de senha?
          // No fluxo proposto, o usuário insere a chave e depois cria a senha.
          // Vamos retornar sucesso e a chave para o frontend prosseguir com a criação da senha.
          return { success: true, keyId: key.id, requiresPassword: true };
        }
      } else if (!userId) {
         throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Usuário não identificado para ativação da chave.",
        });
      }

      // Ativar chave para o usuário logado
      const durationDays = key.durationDays;
      const now = new Date();
      const endsAt = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000);
      const graceUntil = new Date(endsAt.getTime() + 30 * 24 * 60 * 60 * 1000);

      await createLicense({
        userId: userId!,
        sourceKeyId: key.id,
        status: "active",
        startsAt: now,
        endsAt: endsAt,
        graceUntil: graceUntil,
      });

      await useAccessKey(key.id, userId!);

      return { success: true, expiresAt: endsAt };
    }),

  // Validar licença do usuário logado
  validate: protectedProcedure.query(async ({ ctx }) => {
    const license = await getLicenseByUserId(ctx.user.id);
    const activeLicense = await getActiveLicenseByUserId(ctx.user.id);
    
    if (!license) {
      return { status: "no_license" };
    }

    const now = new Date();
    const isExpired = license.endsAt < now;
    const isGracePeriod = !activeLicense && license.graceUntil && license.graceUntil > now;

    const daysRemaining = Math.ceil((new Date(license.endsAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24));

    return {
      status: activeLicense ? "active" : (isGracePeriod ? "grace_period" : "expired"),
      endsAt: license.endsAt,
      graceUntil: license.graceUntil,
      daysRemaining,
    };
  }),

  // Obter status detalhado da licença
  status: protectedProcedure.query(async ({ ctx }) => {
    const license = await getLicenseByUserId(ctx.user.id);
    return license || null;
  }),
});
