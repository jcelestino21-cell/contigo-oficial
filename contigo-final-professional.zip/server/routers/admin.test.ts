import { describe, expect, it } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(role: "admin" | "user" = "admin"): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-admin",
    email: "admin@example.com",
    name: "Admin User",
    displayName: "Admin",
    age: 30,
    activePersonality: "vicente",
    onboardingDone: true,
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("admin router", () => {
  it("should allow admin to list users", async () => {
    const ctx = createAdminContext("admin");
    const caller = appRouter.createCaller(ctx);

    const users = await caller.admin.users({ limit: 10, offset: 0 });

    expect(Array.isArray(users)).toBe(true);
  });

  it("should allow admin to list subscriptions", async () => {
    const ctx = createAdminContext("admin");
    const caller = appRouter.createCaller(ctx);

    const subs = await caller.admin.subscriptions({ limit: 10, offset: 0 });

    expect(Array.isArray(subs)).toBe(true);
  });

  it("should reject non-admin users", async () => {
    const ctx = createAdminContext("user");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.admin.users({ limit: 10, offset: 0 });
      expect.fail("Should have thrown");
    } catch (err: unknown) {
      const error = err as { code?: string };
      expect(error.code).toBe("FORBIDDEN");
    }
  });

  it("should reject unauthenticated users", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    });

    try {
      await caller.admin.users({ limit: 10, offset: 0 });
      expect.fail("Should have thrown");
    } catch (err: unknown) {
      const error = err as { code?: string };
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should allow admin to update user role", async () => {
    const ctx = createAdminContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updateUserRole({
      userId: 2,
      role: "admin",
    });

    expect(result).toEqual({ success: true });
  });

  it("should allow admin to override subscription status", async () => {
    const ctx = createAdminContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.overrideSubscription({
      userId: 2,
      status: "active",
    });

    expect(result).toEqual({ success: true });
  });
});
