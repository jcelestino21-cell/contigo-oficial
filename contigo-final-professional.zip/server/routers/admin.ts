import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  adminUpdateUser,
  getAllUsers,
  getLicenseByUserId,
  getAllLicenses,
  getAllAccessKeys,
  createAccessKey,
  getAllPayments,
  approvePayment,
  upsertPixSettings,
  getPixSettings,
} from "../db";
import { nanoid } from "nanoid";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Acesso restrito a administradores." });
  }
  return next({ ctx });
});

export const adminRouter = router({
  // Usuários
  users: adminProcedure
    .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      return getAllUsers(input.limit, input.offset);
    }),

  updateUser: adminProcedure
    .input(z.object({ 
      userId: z.number(), 
      role: z.enum(["user", "admin"]).optional(),
      isActive: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      await adminUpdateUser(input.userId, input);
      return { success: true };
    }),

  // Chaves de Acesso
  accessKeys: adminProcedure
    .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      return getAllAccessKeys(input.limit, input.offset);
    }),

  generateKey: adminProcedure
    .input(z.object({ 
      type: z.enum(["trial", "renewal", "admin"]),
      durationDays: z.number().default(30),
      maxUses: z.number().default(1),
    }))
    .mutation(async ({ ctx, input }) => {
      const code = nanoid(12).toUpperCase();
      await createAccessKey({
        code,
        type: input.type,
        durationDays: input.durationDays,
        maxUses: input.maxUses,
        createdByUserId: ctx.user.id,
        status: "new",
      });
      return { code };
    }),

  // Licenças
  licenses: adminProcedure
    .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      return getAllLicenses(input.limit, input.offset);
    }),

  userLicense: adminProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      return getLicenseByUserId(input.userId);
    }),

  // Pagamentos Pix
  payments: adminProcedure
    .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      return getAllPayments(input.limit, input.offset);
    }),

  approvePayment: adminProcedure
    .input(z.object({ paymentId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await approvePayment(input.paymentId, ctx.user.id);
      return { success: true };
    }),

  // Configurações do Pix
  pixSettings: adminProcedure.query(async () => {
    return getPixSettings();
  }),

  updatePixSettings: adminProcedure
    .input(z.object({ 
      pixKey: z.string(),
      receiverName: z.string(),
      defaultAmount: z.string().default("7.90"),
      city: z.string().optional(),
      instructions: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      await upsertPixSettings({
        ...input,
        isActive: true,
      });
      return { success: true };
    }),
});
