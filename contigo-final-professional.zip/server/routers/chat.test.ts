import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createChatContext(overrides?: Partial<AuthenticatedUser>): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    displayName: "Test",
    age: 25,
    activePersonality: "vicente",
    onboardingDone: true,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("chat router", () => {
  it("should list message history for a personality", async () => {
    const ctx = createChatContext();
    const caller = appRouter.createCaller(ctx);

    const history = await caller.chat.history({
      personality: "vicente",
      limit: 10,
    });

    expect(Array.isArray(history)).toBe(true);
  });

  it("should return message count and premium status", async () => {
    const ctx = createChatContext();
    const caller = appRouter.createCaller(ctx);

    const count = await caller.chat.messageCount();

    expect(count).toHaveProperty("count");
    expect(count).toHaveProperty("isPremium");
    expect(count).toHaveProperty("limit");
    expect(typeof count.count).toBe("number");
    expect(typeof count.isPremium).toBe("boolean");
  });

  it("should reject unauthenticated users", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    });

    try {
      await caller.chat.messageCount();
      expect.fail("Should have thrown");
    } catch (err: unknown) {
      const error = err as { code?: string };
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should enforce free tier message limit", async () => {
    const ctx = createChatContext();
    const caller = appRouter.createCaller(ctx);

    // This test verifies the limit exists; actual enforcement depends on DB state
    const count = await caller.chat.messageCount();
    expect(count.limit).toBe(20); // FREE_MESSAGE_LIMIT
  });
});
