import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import {
  getUserByOpenId,
  upsertUser,
  getAccessKeyByCode,
  useAccessKey,
  createLicense,
} from "../db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "../_core/cookies";
import { sign } from "jose"; // Usando jose para JWT se necessário, ou apenas cookies de sessão
// Nota: O sistema original parece usar cookies de sessão com um token/ID.

// Funções auxiliares simples para hash de senha (em produção usar bcrypt/argon2)
// Como o ambiente manus-runtime tem jose, vamos usar o que estiver disponível ou simular
async function hashPassword(password: string): Promise<string> {
  // Simulação simples de hash para este ambiente
  return `hashed_${password}`;
}

async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return `hashed_${password}` === hash;
}

export const authRouter = router({
  // Registro/Ativação inicial com chave
  registerWithKey: publicProcedure
    .input(z.object({
      code: z.string().min(4),
      openId: z.string().min(3), // O identificador único do usuário (ex: email ou nick)
      password: z.string().min(6),
    }))
    .mutation(async ({ ctx, input }) => {
      // 1. Validar chave
      const key = await getAccessKeyByCode(input.code);
      if (!key || key.status !== "new") {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Chave inválida ou já utilizada.",
        });
      }

      // 2. Verificar se usuário já existe
      const existingUser = await getUserByOpenId(input.openId);
      if (existingUser) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Este identificador já está em uso.",
        });
      }

      // 3. Criar usuário com hash de senha
      const passwordHash = await hashPassword(input.password);
      await upsertUser({
        openId: input.openId,
        passwordHash: passwordHash,
        loginMethod: "key_activation",
        role: key.type === "admin" ? "admin" : "user",
        isActive: true,
      });

      const user = await getUserByOpenId(input.openId);
      if (!user) throw new Error("Falha ao criar usuário.");

      // 4. Criar licença inicial baseada na chave
      const now = new Date();
      const endsAt = new Date(now.getTime() + key.durationDays * 24 * 60 * 60 * 1000);
      const graceUntil = new Date(endsAt.getTime() + 30 * 24 * 60 * 60 * 1000);

      await createLicense({
        userId: user.id,
        sourceKeyId: key.id,
        status: "active",
        startsAt: now,
        endsAt: endsAt,
        graceUntil: graceUntil,
      });

      // 5. Marcar chave como usada
      await useAccessKey(key.id, user.id);

      // 6. Login automático (definir cookie)
      // O sistema original gerencia o cookie via middleware/context
      // Vamos assumir que o openId no cookie é o que o sistema espera
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, user.openId, cookieOptions);

      return { success: true, user };
    }),

  // Login tradicional com senha
  login: publicProcedure
    .input(z.object({
      openId: z.string(),
      password: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const user = await getUserByOpenId(input.openId);
      
      if (!user || !user.passwordHash) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Credenciais inválidas.",
        });
      }

      const isValid = await verifyPassword(input.password, user.passwordHash);
      if (!isValid) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Credenciais inválidas.",
        });
      }

      if (!user.isActive) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Sua conta está desativada.",
        });
      }

      // Definir cookie de sessão
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, user.openId, cookieOptions);

      return { success: true, user };
    }),

  // Obter usuário atual (já existe no routers.ts, mas vamos reforçar aqui se necessário)
  me: publicProcedure.query(({ ctx }) => ctx.user),

  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true };
  }),
});
