import {
  boolean,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  passwordHash: text("passwordHash"), // Nova coluna para senha
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isActive: boolean("isActive").default(true).notNull(), // Nova coluna
  lastAccessAt: timestamp("lastAccessAt").defaultNow().notNull(), // Nova coluna
  // Onboarding
  displayName: varchar("displayName", { length: 100 }),
  age: int("age"),
  onboardingDone: boolean("onboardingDone").default(false).notNull(),
  activePersonality: varchar("activePersonality", { length: 20 }).default("vicente"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Access Keys
export const accessKeys = mysqlTable("access_keys", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull().unique(),
  type: mysqlEnum("type", ["trial", "renewal", "admin"]).notNull(),
  status: mysqlEnum("status", ["new", "used", "expired", "revoked"]).default("new").notNull(),
  durationDays: int("durationDays").notNull(),
  maxUses: int("maxUses").default(1).notNull(),
  usedCount: int("usedCount").default(0).notNull(),
  usedByUserId: int("usedByUserId"),
  createdByUserId: int("createdByUserId"),
  expiresAt: timestamp("expiresAt"),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AccessKey = typeof accessKeys.$inferSelect;
export type InsertAccessKey = typeof accessKeys.$inferInsert;

// Licenses
export const licenses = mysqlTable("licenses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sourceKeyId: int("sourceKeyId"),
  status: mysqlEnum("status", ["active", "expired", "pending_payment", "blocked"]).default("active").notNull(),
  startsAt: timestamp("startsAt").defaultNow().notNull(),
  endsAt: timestamp("endsAt").notNull(),
  graceUntil: timestamp("graceUntil"), // 30 dias após vencimento
  lastPaymentAt: timestamp("lastPaymentAt"),
  renewalPrice: decimal("renewalPrice", { precision: 10, scale: 2 }).default("7.90").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type License = typeof licenses.$inferSelect;
export type InsertLicense = typeof licenses.$inferInsert;

// Payments (Pix manual)
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  licenseId: int("licenseId"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  method: varchar("method", { length: 20 }).default("pix").notNull(),
  status: mysqlEnum("status", ["pending", "paid", "failed", "expired", "manual_review"]).default("pending").notNull(),
  pixCopyPaste: text("pixCopyPaste"),
  qrCodeText: text("qrCodeText"),
  transactionRef: varchar("transactionRef", { length: 128 }),
  proofUrl: text("proofUrl"),
  paidAt: timestamp("paidAt"),
  approvedByAdminId: int("approvedByAdminId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

// Pix Settings
export const pixSettings = mysqlTable("pix_settings", {
  id: int("id").autoincrement().primaryKey(),
  pixKey: varchar("pixKey", { length: 255 }).notNull(),
  receiverName: varchar("receiverName", { length: 255 }).notNull(),
  city: varchar("city", { length: 100 }).default("SAO PAULO").notNull(),
  defaultAmount: decimal("defaultAmount", { precision: 10, scale: 2 }).default("7.90").notNull(),
  instructions: text("instructions"),
  isActive: boolean("isActive").default(true).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PixSetting = typeof pixSettings.$inferSelect;
export type InsertPixSetting = typeof pixSettings.$inferInsert;

// Messages
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  personality: varchar("personality", { length: 20 }).notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  emotionalContext: text("emotionalContext"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// Personalities (static seed data reference)
export const personalities = mysqlTable("personalities", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 50 }).notNull(),
  archetype: varchar("archetype", { length: 50 }),
  description: text("description"),
  systemPrompt: text("systemPrompt"),
  accentColor: varchar("accentColor", { length: 20 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Personality = typeof personalities.$inferSelect;
export type InsertPersonality = typeof personalities.$inferInsert;

// Antiga tabela de assinaturas (mantida para compatibilidade durante migração se necessário, mas será descontinuada)
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["active", "overdue", "canceled", "trialing", "free"]).default("free").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 128 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 128 }),
  stripePriceId: varchar("stripePriceId", { length: 128 }),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  cancelAtPeriodEnd: boolean("cancelAtPeriodEnd").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
