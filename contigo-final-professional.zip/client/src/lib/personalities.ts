import { PERSONALITIES, type PersonalityInfo, getPersonality as getSharedPersonality } from "@shared/personalities";

export type { PersonalityInfo };
export { PERSONALITIES };

export function getPersonality(slug: string): PersonalityInfo {
  return getSharedPersonality(slug);
}
