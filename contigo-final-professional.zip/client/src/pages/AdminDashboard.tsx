import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

type Tab = "dashboard" | "payments" | "users" | "keys" | "settings";

export default function AdminDashboard() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const [tab, setTab] = useState<Tab>("dashboard");

  useEffect(() => {
    if (!loading && (!isAuthenticated || user?.role !== "admin")) {
      navigate("/");
    }
  }, [loading, isAuthenticated, user, navigate]);

  const usersQuery = trpc.admin.users.useQuery({ limit: 100, offset: 0 }, { enabled: user?.role === "admin" });
  const paymentsQuery = trpc.admin.payments.useQuery({ limit: 100, offset: 0 }, { enabled: user?.role === "admin" });
  const keysQuery = trpc.admin.accessKeys.useQuery({ limit: 100, offset: 0 }, { enabled: user?.role === "admin" });
  const pixSettingsQuery = trpc.admin.pixSettings.useQuery(undefined, { enabled: user?.role === "admin" });

  const generateKeyMutation = trpc.admin.generateKey.useMutation({
    onSuccess: (data) => {
      toast.success(`Chave gerada: ${data.code}`);
      keysQuery.refetch();
    },
  });

  const approvePaymentMutation = trpc.admin.approvePayment.useMutation({
    onSuccess: () => {
      toast.success("Pagamento aprovado!");
      paymentsQuery.refetch();
    },
  });

  const updatePixMutation = trpc.admin.updatePixSettings.useMutation({
    onSuccess: () => {
      toast.success("Configurações Pix atualizadas!");
      pixSettingsQuery.refetch();
    },
  });

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-5 h-5 rounded-full border border-muted-foreground/20 border-t-primary animate-spin" />
      </div>
    );
  }

  if (user.role !== "admin") return null;

  const totalRevenue = paymentsQuery.data?.filter(p => p.status === "paid").reduce((acc, p) => acc + Number(p.amount), 0) || 0;
  const pendingPayments = paymentsQuery.data?.filter(p => p.status === "pending").length || 0;
  const newKeys = keysQuery.data?.filter(k => k.status === "new").length || 0;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div
        className="flex items-center justify-between px-6 py-4 border-b"
        style={{ borderColor: "oklch(0.18 0.02 260)" }}
      >
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/chat")} style={{ color: "oklch(0.50 0.02 260)" }}>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-lg font-medium" style={{ fontFamily: "'Lora', serif", color: "oklch(0.92 0.01 260)" }}>
            painel de controle
          </h1>
        </div>
        <span className="text-xs px-2 py-1 rounded-full" style={{ background: "oklch(0.72 0.12 280 / 0.15)", color: "oklch(0.72 0.12 280)" }}>
          admin
        </span>
      </div>

      {/* Tabs */}
      <div className="flex px-6 gap-1 border-b overflow-x-auto" style={{ borderColor: "oklch(0.18 0.02 260)" }}>
        {(["dashboard", "payments", "users", "keys", "settings"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="px-4 py-2.5 text-sm border-b-2 transition-colors whitespace-nowrap"
            style={{
              borderColor: tab === t ? "oklch(0.72 0.12 280)" : "transparent",
              color: tab === t ? "oklch(0.85 0.01 260)" : "oklch(0.50 0.02 260)",
            }}
          >
            {t === "dashboard" ? "receita" : t === "payments" ? "pagamentos" : t === "users" ? "usuários" : t === "keys" ? "chaves" : "config"}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        {tab === "dashboard" && (
          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {[
                { label: "Receita Total", value: `R$ ${totalRevenue.toFixed(2)}`, color: "#5B9E8A" },
                { label: "Pagamentos Pendentes", value: pendingPayments, color: "#E8A838" },
                { label: "Chaves Novas", value: newKeys, color: "#4A90D9" },
                { label: "Total Usuários", value: usersQuery.data?.length || 0, color: "#7C6FCD" },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-xl p-4 border"
                  style={{
                    background: `${stat.color}15`,
                    borderColor: `${stat.color}40`,
                  }}
                >
                  <p className="text-2xl font-light" style={{ color: stat.color }}>
                    {stat.value}
                  </p>
                  <p className="text-xs mt-1" style={{ color: "oklch(0.50 0.02 260)" }}>
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "payments" && (
          <div className="flex flex-col gap-2">
            {paymentsQuery.data?.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between p-4 rounded-xl border"
                style={{ background: "oklch(0.12 0.015 260)", borderColor: "oklch(0.22 0.02 260)" }}
              >
                <div>
                  <p className="text-sm font-medium" style={{ color: "oklch(0.88 0.01 260)" }}>
                    User #{p.userId}
                  </p>
                  <p className="text-xs mt-1" style={{ color: "oklch(0.50 0.02 260)" }}>
                    R$ {p.amount} • {new Date(p.createdAt).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <div className="text-right flex items-center gap-3">
                  <span
                    className="text-xs px-2 py-0.5 rounded-full"
                    style={{
                      background: p.status === "paid" ? "#5B9E8A20" : "#E8A83820",
                      color: p.status === "paid" ? "#5B9E8A" : "#E8A838",
                    }}
                  >
                    {p.status}
                  </span>
                  {p.status === "pending" && (
                    <button
                      onClick={() => approvePaymentMutation.mutate({ paymentId: p.id })}
                      className="text-xs underline"
                      style={{ color: "oklch(0.72 0.12 280)" }}
                    >
                      Aprovar
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "users" && (
          <div className="flex flex-col gap-2">
            {usersQuery.data?.map((u) => (
              <div
                key={u.id}
                className="flex items-center justify-between p-4 rounded-xl border"
                style={{ background: "oklch(0.12 0.015 260)", borderColor: "oklch(0.22 0.02 260)" }}
              >
                <div>
                  <p className="text-sm font-medium" style={{ color: "oklch(0.88 0.01 260)" }}>
                    {u.displayName ?? u.openId}
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: "oklch(0.50 0.02 260)" }}>
                    ID: {u.openId} • {u.role}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "keys" && (
          <div className="flex flex-col gap-4">
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => generateKeyMutation.mutate({ type: "trial", durationDays: 7 })}
                className="text-xs px-4 py-2 rounded-full"
                style={{ background: "oklch(0.72 0.12 280)", color: "oklch(0.09 0.01 260)" }}
              >
                Gerar Trial (7d)
              </button>
              <button
                onClick={() => generateKeyMutation.mutate({ type: "renewal", durationDays: 30 })}
                className="text-xs px-4 py-2 rounded-full border"
                style={{ borderColor: "oklch(0.30 0.03 280)", color: "oklch(0.85 0.01 260)" }}
              >
                Gerar Renovação (30d)
              </button>
            </div>
            {keysQuery.data?.map((k) => (
              <div
                key={k.id}
                className="flex items-center justify-between p-4 rounded-xl border"
                style={{ background: "oklch(0.12 0.015 260)", borderColor: "oklch(0.22 0.02 260)" }}
              >
                <div>
                  <p className="text-sm font-mono font-bold" style={{ color: "oklch(0.92 0.01 260)" }}>
                    {k.code}
                  </p>
                  <p className="text-xs mt-1" style={{ color: "oklch(0.50 0.02 260)" }}>
                    {k.type} • {k.durationDays} dias
                  </p>
                </div>
                <span
                  className="text-xs px-2 py-0.5 rounded-full"
                  style={{
                    background: k.status === "new" ? "#5B9E8A20" : "#C0392B20",
                    color: k.status === "new" ? "#5B9E8A" : "#C0392B",
                  }}
                >
                  {k.status}
                </span>
              </div>
            ))}
          </div>
        )}

        {tab === "settings" && (
          <div className="max-w-md">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                updatePixMutation.mutate({
                  pixKey: formData.get("pixKey") as string,
                  receiverName: formData.get("receiverName") as string,
                  defaultAmount: formData.get("defaultAmount") as string,
                });
              }}
              className="flex flex-col gap-6"
            >
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest" style={{ color: "oklch(0.50 0.02 260)" }}>Chave Pix</label>
                <input
                  name="pixKey"
                  defaultValue={pixSettingsQuery.data?.pixKey}
                  className="bg-transparent border-b py-2 outline-none"
                  style={{ borderColor: "oklch(0.30 0.03 280)", color: "oklch(0.92 0.01 260)" }}
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest" style={{ color: "oklch(0.50 0.02 260)" }}>Nome Recebedor</label>
                <input
                  name="receiverName"
                  defaultValue={pixSettingsQuery.data?.receiverName}
                  className="bg-transparent border-b py-2 outline-none"
                  style={{ borderColor: "oklch(0.30 0.03 280)", color: "oklch(0.92 0.01 260)" }}
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest" style={{ color: "oklch(0.50 0.02 260)" }}>Valor Padrão</label>
                <input
                  name="defaultAmount"
                  defaultValue={pixSettingsQuery.data?.defaultAmount}
                  className="bg-transparent border-b py-2 outline-none"
                  style={{ borderColor: "oklch(0.30 0.03 280)", color: "oklch(0.92 0.01 260)" }}
                />
              </div>
              <button
                type="submit"
                className="py-3 rounded-full text-sm font-medium transition-all"
                style={{ background: "oklch(0.72 0.12 280)", color: "oklch(0.09 0.01 260)" }}
              >
                salvar configurações
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
