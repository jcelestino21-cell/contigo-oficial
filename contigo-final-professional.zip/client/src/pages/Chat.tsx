import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { getPersonality, PERSONALITIES, type PersonalitySlug } from "@/lib/personalities";
import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

interface Message {
  id?: number;
  role: "user" | "assistant";
  content: string;
  personality?: string;
  createdAt?: Date;
  isNew?: boolean;
}

function TypingIndicator({ color }: { color: string }) {
  return (
    <div className="flex items-center gap-1 px-4 py-3 rounded-2xl rounded-bl-sm w-fit" style={{ background: "oklch(0.15 0.015 260)" }}>
      <span className="typing-dot w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
      <span className="typing-dot w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
      <span className="typing-dot w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
    </div>
  );
}

export default function Chat() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const [activePersonality, setActivePersonality] = useState<PersonalitySlug>((user?.activePersonality as PersonalitySlug) ?? "vicente");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [showPersonalityMenu, setShowPersonalityMenu] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const personality = getPersonality(activePersonality);

  const { data: licenseStatus, isLoading: loadingLicense } = trpc.licenses.validate.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const historyQuery = trpc.chat.history.useQuery(
    { personality: activePersonality, limit: 40 },
    { enabled: isAuthenticated }
  );

  const selectPersonalityMutation = trpc.personalities.select.useMutation();

  const sendMutation = trpc.chat.send.useMutation({
    onMutate: () => {
      setIsTyping(true);
    },
    onSuccess: (data) => {
      const delay = 400 + Math.random() * 600;
      setTimeout(() => {
        setIsTyping(false);
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: data.reply, personality: activePersonality, isNew: true },
        ]);
      }, delay);
    },
    onError: (err) => {
      setIsTyping(false);
      // Tratamento de erro padronizado com código interno se disponível
      const internalCode = (err.data as any)?.internalCode;
      if (internalCode === 10001 || err.message.includes("expirou")) {
        toast.error("Sua licença expirou", {
          action: { label: "renovar", onClick: () => navigate("/subscribe") },
        });
      } else {
        toast.error(err.message || "algo deu errado. tenta de novo.");
      }
    },
  });

  useEffect(() => {
    if (historyQuery.data) {
      setMessages(historyQuery.data.map((m) => ({ ...m, isNew: false })));
    }
  }, [historyQuery.data]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  useEffect(() => {
    if (!loading && !isAuthenticated) navigate("/login");
    if (!loading && isAuthenticated && user && !user.onboardingDone) navigate("/onboarding");
  }, [loading, isAuthenticated, user, navigate]);

  function handleSend() {
    const text = input.trim();
    if (!text || sendMutation.isPending || licenseStatus?.status === "expired") return;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: text, isNew: true }]);
    sendMutation.mutate({ message: text, personality: activePersonality });
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  function switchPersonality(slug: PersonalitySlug) {
    setActivePersonality(slug);
    setShowPersonalityMenu(false);
    selectPersonalityMutation.mutate({ slug });
    historyQuery.refetch();
  }

  const isBlocked = licenseStatus?.status === "expired";
  const isGrace = licenseStatus?.status === "grace_period";
  const daysLeft = (licenseStatus as any)?.daysRemaining;

  if (loading || loadingLicense) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 rounded-full border border-muted-foreground/20 border-t-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden relative">
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 py-3 border-b relative z-20"
        style={{ borderColor: "oklch(0.18 0.02 260)" }}
      >
        <button
          onClick={() => setShowPersonalityMenu((v) => !v)}
          className="flex items-center gap-2.5 group"
        >
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all"
            style={{
              background: `${personality.accentColor}25`,
              border: `1px solid ${personality.accentColor}60`,
            }}
          >
            {personality.emoji}
          </div>
          <div className="text-left">
            <p className="text-sm font-medium leading-none" style={{ color: "oklch(0.88 0.01 260)" }}>
              {personality.name}
            </p>
            <p className="text-[10px] uppercase tracking-widest mt-0.5" style={{ color: "oklch(0.50 0.02 260)" }}>
              {personality.useCase}
            </p>
          </div>
          <svg className="w-3 h-3 ml-1" style={{ color: "oklch(0.45 0.02 260)" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/subscribe")}
            className="text-xs px-3 py-1.5 rounded-full border transition-colors"
            style={{ 
              borderColor: isBlocked ? "oklch(0.65 0.18 25)" : "oklch(0.25 0.02 260)", 
              color: isBlocked ? "oklch(0.65 0.18 25)" : "oklch(0.55 0.02 260)" 
            }}
          >
            {isBlocked ? "licença expirada" : "renovar"}
          </button>
        </div>
      </div>

      {/* Renewal Alerts */}
      {!isBlocked && daysLeft !== undefined && daysLeft <= 3 && (
        <div 
          className="px-4 py-2 text-center text-[10px] uppercase tracking-widest font-bold"
          style={{ 
            background: daysLeft <= 1 ? "oklch(0.65 0.18 25 / 0.15)" : "oklch(0.72 0.12 280 / 0.1)",
            color: daysLeft <= 1 ? "oklch(0.65 0.18 25)" : "oklch(0.72 0.12 280)",
            borderBottom: `1px solid ${daysLeft <= 1 ? "oklch(0.65 0.18 25 / 0.2)" : "oklch(0.72 0.12 280 / 0.2)"}`
          }}
        >
          {daysLeft === 0 ? "sua licença vence hoje. renove para não perder o fio da conversa." : 
           daysLeft === 1 ? "sua licença vence amanhã. garanta sua presença." : 
           `faltam ${daysLeft} dias para sua licença expirar.`}
        </div>
      )}

      {/* Personality dropdown */}
      {showPersonalityMenu && (
        <div
          className="absolute top-14 left-4 right-4 z-30 rounded-xl border overflow-hidden shadow-xl"
          style={{ background: "oklch(0.13 0.015 260)", borderColor: "oklch(0.22 0.02 260)" }}
        >
          {PERSONALITIES.map((p) => (
            <button
              key={p.slug}
              onClick={() => switchPersonality(p.slug)}
              className="w-full flex items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-white/5"
              style={{
                background: activePersonality === p.slug ? `${p.accentColor}15` : "transparent",
              }}
            >
              <span>{p.emoji}</span>
              <div className="flex flex-col">
                <div className="flex items-center">
                  <span className="text-sm font-medium" style={{ color: activePersonality === p.slug ? p.accentColor : "oklch(0.85 0.01 260)" }}>
                    {p.name}
                  </span>
                  <span className="text-[10px] uppercase tracking-tighter ml-2" style={{ color: "oklch(0.45 0.02 260)" }}>
                    {p.subTitle}
                  </span>
                </div>
                <span className="text-[10px] text-zinc-500 italic mt-0.5">{p.useCase}</span>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Messages */}
      <div className={`flex-1 overflow-y-auto px-4 py-6 flex flex-col gap-3 ${isBlocked ? 'opacity-40 grayscale-[0.5]' : ''}`}>
        {historyQuery.isLoading && (
          <div className="flex justify-center py-8">
            <div className="w-5 h-5 rounded-full border border-muted-foreground/20 border-t-primary animate-spin" />
          </div>
        )}

        {messages.length === 0 && !historyQuery.isLoading && (
          <div className="flex flex-col items-center justify-center flex-1 gap-3 text-center py-12">
            <span className="text-4xl">{personality.emoji}</span>
            <p className="text-sm italic" style={{ color: "oklch(0.50 0.02 260)", fontFamily: "'Lora', serif" }}>
              "{personality.exampleLine}"
            </p>
            <p className="text-xs" style={{ color: "oklch(0.38 0.02 260)" }}>
              — {personality.name}
            </p>
          </div>
        )}

        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} ${msg.isNew ? "message-in" : ""}`}
          >
            {msg.role === "assistant" && (
              <div
                className="w-6 h-6 rounded-full flex items-center justify-center text-xs mr-2 mt-1 flex-shrink-0"
                style={{ background: `${personality.accentColor}20`, border: `1px solid ${personality.accentColor}40` }}
              >
                {personality.emoji}
              </div>
            )}
            <div
              className="max-w-[78%] px-4 py-3 rounded-2xl text-sm leading-relaxed"
              style={
                msg.role === "user"
                  ? {
                      background: "oklch(0.72 0.12 280 / 0.2)",
                      color: "oklch(0.92 0.01 260)",
                      borderRadius: "18px 18px 4px 18px",
                    }
                  : {
                      background: "oklch(0.14 0.015 260)",
                      color: "oklch(0.88 0.01 260)",
                      borderRadius: "4px 18px 18px 18px",
                      borderLeft: `2px solid ${personality.accentColor}60`,
                    }
              }
            >
              {msg.content}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start message-in">
            <div
              className="w-6 h-6 rounded-full flex items-center justify-center text-xs mr-2 mt-1 flex-shrink-0"
              style={{ background: `${personality.accentColor}20`, border: `1px solid ${personality.accentColor}40` }}
            >
              {personality.emoji}
            </div>
            <TypingIndicator color={personality.accentColor} />
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Blocked Overlay */}
      {isBlocked && (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-40 flex items-center justify-center p-6 text-center">
          <div className="bg-zinc-950 border border-zinc-800 p-8 rounded-2xl max-w-sm space-y-6 shadow-[0_0_50px_rgba(0,0,0,0.5)]">
            <div className="w-16 h-16 bg-zinc-900 border border-zinc-800 rounded-full flex items-center justify-center mx-auto text-2xl">
              🕊️
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-serif text-zinc-100">Sua conversa está guardada.</h3>
              <p className="text-zinc-500 text-sm leading-relaxed">
                Sua conexão com as personalidades e todo seu histórico estão preservados. 
                Renove sua licença para continuar de onde parou.
              </p>
            </div>
            <button
              onClick={() => navigate("/subscribe")}
              className="w-full py-3.5 bg-zinc-100 text-zinc-950 rounded-full font-bold uppercase tracking-widest text-[10px] hover:bg-zinc-300 transition-colors shadow-lg"
            >
              Renovar Licença
            </button>
          </div>
        </div>
      )}

      {/* Input */}
      <div
        className="px-4 py-3 border-t"
        style={{ borderColor: "oklch(0.18 0.02 260)" }}
      >
        <div
          className="flex items-end gap-3 rounded-2xl px-4 py-2.5"
          style={{
            background: "oklch(0.14 0.015 260)",
            border: "1px solid oklch(0.22 0.02 260)",
          }}
        >
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isBlocked ? "Renove para continuar…" : "escreve aqui…"}
            disabled={isBlocked}
            rows={1}
            className="flex-1 bg-transparent resize-none outline-none text-sm leading-relaxed placeholder:text-muted-foreground/40 max-h-32"
            style={{ color: "oklch(0.88 0.01 260)" }}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || sendMutation.isPending || isBlocked}
            className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all disabled:opacity-30"
            style={{
              background: input.trim() && !isBlocked ? "oklch(0.72 0.12 280)" : "oklch(0.22 0.02 260)",
              color: "oklch(0.09 0.01 260)",
            }}
          >
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
