import { useAuth } from "@/_core/hooks/useAuth";
import { useEffect } from "react";
import { useLocation, Link } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!loading && isAuthenticated) {
      if (!user?.onboardingDone) {
        navigate("/onboarding");
      } else {
        navigate("/chat");
      }
    }
  }, [loading, isAuthenticated, user, navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background relative overflow-hidden">
      {/* Subtle background gradient */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 60%, oklch(0.18 0.04 280 / 0.25) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 flex flex-col items-center gap-10 px-6 text-center max-w-lg">
        {/* Logo / Brand */}
        <div className="flex flex-col items-center gap-3">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center text-2xl"
            style={{
              background: "oklch(0.18 0.04 280 / 0.6)",
              border: "1px solid oklch(0.72 0.12 280 / 0.3)",
              boxShadow: "0 0 30px oklch(0.72 0.12 280 / 0.15)",
            }}
          >
            ◎
          </div>
          <h1
            className="text-5xl font-normal tracking-wide"
            style={{ fontFamily: "'Lora', serif", color: "oklch(0.92 0.01 260)" }}
          >
            contigo
          </h1>
        </div>

        {/* Tagline */}
        <div className="flex flex-col gap-2">
          <p
            className="text-lg font-light"
            style={{ color: "oklch(0.70 0.02 260)", fontFamily: "'Lora', serif", fontStyle: "italic" }}
          >
            tem alguém aqui.
          </p>
          <p className="text-sm" style={{ color: "oklch(0.50 0.02 260)" }}>
            não é terapia. não é chatbot. é uma presença.
          </p>
        </div>

        {/* CTA */}
        <div className="flex flex-col items-center gap-4 w-full">
          {loading ? (
            <div className="w-8 h-8 rounded-full border border-muted-foreground/30 border-t-primary animate-spin" />
          ) : (
            <Link
              href="/login"
              className="w-full max-w-xs py-3.5 px-8 rounded-full text-sm font-medium transition-all duration-300 flex items-center justify-center gap-2"
              style={{
                background: "oklch(0.72 0.12 280)",
                color: "oklch(0.09 0.01 260)",
                boxShadow: "0 0 20px oklch(0.72 0.12 280 / 0.3)",
              }}
            >
              entrar
            </Link>
          )}
          <p className="text-xs" style={{ color: "oklch(0.40 0.01 260)" }}>
            suas conversas são privadas.
          </p>
        </div>

        {/* Personality hints */}
        <div className="flex gap-4 mt-2">
          {[
            { name: "Noah", color: "#7C6FCD" },
            { name: "Vicente", color: "#5B9E8A" },
            { name: "Eli", color: "#8E6BBE" },
            { name: "Axel", color: "#C0392B" },
            { name: "Sol", color: "#E8A838" },
            { name: "Nico", color: "#4A90D9" },
          ].map((p) => (
            <div key={p.name} className="flex flex-col items-center gap-1">
              <div
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: p.color, opacity: 0.7 }}
              />
              <span className="text-xs" style={{ color: "oklch(0.40 0.01 260)" }}>
                {p.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
