import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function Login() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  
  // Login states
  const [loginId, setLoginId] = useState("");
  const [loginPass, setLoginPass] = useState("");

  // Register states
  const [regKey, setRegKey] = useState("");
  const [regId, setRegId] = useState("");
  const [regPass, setRegPass] = useState("");

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: () => {
      toast.success("Login realizado com sucesso!");
      setLocation("/chat");
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao fazer login.");
    },
  });

  const registerMutation = trpc.auth.registerWithKey.useMutation({
    onSuccess: () => {
      toast.success("Chave ativada e conta criada!");
      setLocation("/onboarding");
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao ativar chave.");
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ openId: loginId, password: loginPass });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    registerMutation.mutate({ 
      code: regKey, 
      openId: regId, 
      password: regPass 
    });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-zinc-950 border-zinc-800">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-serif text-zinc-100">contigo</CardTitle>
          <CardDescription>Sua presença digital.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-zinc-900">
              <TabsTrigger value="login">Entrar</TabsTrigger>
              <TabsTrigger value="register">Ativar Chave</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-id">Identificador (ID)</Label>
                  <Input 
                    id="login-id" 
                    placeholder="Seu ID ou email" 
                    value={loginId} 
                    onChange={(e) => setLoginId(e.target.value)}
                    className="bg-zinc-900 border-zinc-800"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-pass">Senha</Label>
                  <Input 
                    id="login-pass" 
                    type="password" 
                    placeholder="Sua senha" 
                    value={loginPass} 
                    onChange={(e) => setLoginPass(e.target.value)}
                    className="bg-zinc-900 border-zinc-800"
                    required
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-zinc-100 text-zinc-950 hover:bg-zinc-300"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? "Entrando..." : "Acessar"}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reg-key">Chave de Acesso</Label>
                  <Input 
                    id="reg-key" 
                    placeholder="XXXX-XXXX-XXXX" 
                    value={regKey} 
                    onChange={(e) => setRegKey(e.target.value)}
                    className="bg-zinc-900 border-zinc-800"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-id">Criar ID de Usuário</Label>
                  <Input 
                    id="reg-id" 
                    placeholder="Como você quer ser identificado?" 
                    value={regId} 
                    onChange={(e) => setRegId(e.target.value)}
                    className="bg-zinc-900 border-zinc-800"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-pass">Criar Senha</Label>
                  <Input 
                    id="reg-pass" 
                    type="password" 
                    placeholder="Mínimo 6 caracteres" 
                    value={regPass} 
                    onChange={(e) => setRegPass(e.target.value)}
                    className="bg-zinc-900 border-zinc-800"
                    required
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-zinc-100 text-zinc-950 hover:bg-zinc-300"
                  disabled={registerMutation.isPending}
                >
                  {registerMutation.isPending ? "Ativando..." : "Ativar e Criar Conta"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-center border-t border-zinc-800 pt-4">
          <p className="text-xs text-zinc-500">
            Não tem uma chave? Solicite ao administrador.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
