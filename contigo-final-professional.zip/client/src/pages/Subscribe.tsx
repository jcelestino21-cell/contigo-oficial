import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Subscribe() {
  const { isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const [pixRequested, setPixRequested] = useState(false);

  const licenseQuery = trpc.licenses.validate.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: pixSettings } = trpc.payments.getSettings.useQuery(undefined, {
    enabled: pixRequested,
  });

  const requestRenewalMutation = trpc.payments.requestRenewal.useMutation({
    onSuccess: () => {
      setPixRequested(true);
      toast.success("Solicitação de renovação criada!");
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao solicitar renovação.");
    },
  });

  useEffect(() => {
    if (!loading && !isAuthenticated) navigate("/login");
  }, [loading, isAuthenticated, navigate]);

  const licenseStatus = licenseQuery.data;
  const isActive = licenseStatus?.status === "active";

  function handleRequestPix() {
    requestRenewalMutation.mutate({});
  }

  function copyPix() {
    if (pixSettings?.pixKey) {
      navigator.clipboard.writeText(pixSettings.pixKey);
      toast.success("Chave Pix copiada!");
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-6 relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 40%, oklch(0.18 0.04 280 / 0.2) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 w-full max-w-md flex flex-col gap-8">
        {/* Header */}
        <div className="text-center">
          <button
            onClick={() => navigate("/chat")}
            className="text-xs mb-6 flex items-center gap-1 mx-auto"
            style={{ color: "oklch(0.50 0.02 260)" }}
          >
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            voltar
          </button>
          <h1
            className="text-3xl font-normal"
            style={{ fontFamily: "'Lora', serif", color: "oklch(0.92 0.01 260)" }}
          >
            {isActive ? "sua licença" : "continue presente"}
          </h1>
          <p className="text-sm mt-2" style={{ color: "oklch(0.55 0.02 260)" }}>
            {isActive
              ? "você tem acesso completo ao Contigo."
              : "sua licença expirou ou está prestes a vencer."}
          </p>
        </div>

        {licenseQuery.isLoading ? (
          <div className="flex justify-center py-8">
            <div className="w-5 h-5 rounded-full border border-muted-foreground/20 border-t-primary animate-spin" />
          </div>
        ) : !pixRequested ? (
          /* Initial State / Status View */
          <div className="flex flex-col gap-4">
            <div
              className="rounded-2xl p-6 border text-center"
              style={{
                background: isActive ? "oklch(0.72 0.12 280 / 0.08)" : "oklch(0.65 0.18 25 / 0.08)",
                borderColor: isActive ? "oklch(0.72 0.12 280 / 0.3)" : "oklch(0.65 0.18 25 / 0.3)",
              }}
            >
              <div className="text-3xl mb-3">{isActive ? "✦" : "🔒"}</div>
              <p className="font-medium" style={{ color: isActive ? "oklch(0.72 0.12 280)" : "oklch(0.65 0.18 25)" }}>
                {isActive ? "licença ativa" : "licença expirada"}
              </p>
              {licenseStatus?.endsAt && (
                <p className="text-xs mt-1" style={{ color: "oklch(0.55 0.02 260)" }}>
                  {isActive ? "vence em " : "venceu em "}
                  {new Date(licenseStatus.endsAt).toLocaleDateString("pt-BR")}
                </p>
              )}
            </div>

            <div
              className="rounded-2xl p-5 border relative overflow-hidden"
              style={{
                background: "oklch(0.72 0.12 280 / 0.06)",
                borderColor: "oklch(0.72 0.12 280 / 0.4)",
              }}
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <p className="font-medium text-sm" style={{ color: "oklch(0.92 0.01 260)" }}>
                    renovação mensal
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: "oklch(0.55 0.02 260)" }}>
                    presença completa
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xl font-light" style={{ color: "oklch(0.92 0.01 260)" }}>
                    R$ 7
                  </span>
                  <span className="text-sm" style={{ color: "oklch(0.55 0.02 260)" }}>
                    ,90/mês
                  </span>
                </div>
              </div>
              <ul className="flex flex-col gap-1.5">
                {[
                  "mensagens ilimitadas",
                  "todas as 6 personalidades (incluindo Eli)",
                  "histórico preservado",
                  "memória emocional entre sessões",
                ].map((f) => (
                  <li key={f} className="flex items-center gap-2 text-xs" style={{ color: "oklch(0.70 0.02 260)" }}>
                    <span style={{ color: "oklch(0.72 0.12 280)" }}>✦</span>
                    {f}
                  </li>
                ))}
              </ul>
            </div>

            <button
              onClick={handleRequestPix}
              disabled={requestRenewalMutation.isPending}
              className="w-full py-3.5 rounded-full text-sm font-medium transition-all duration-300"
              style={{
                background: "oklch(0.72 0.12 280)",
                color: "oklch(0.09 0.01 260)",
                boxShadow: "0 0 25px oklch(0.72 0.12 280 / 0.35)",
              }}
            >
              {requestRenewalMutation.isPending ? "processando..." : "renovar via Pix"}
            </button>
          </div>
        ) : (
          /* Pix Payment View */
          <div className="flex flex-col gap-6 text-center">
            <div className="bg-white p-4 rounded-2xl inline-block mx-auto shadow-xl">
              <div className="w-48 h-48 bg-zinc-100 flex items-center justify-center text-zinc-400 text-[10px] uppercase tracking-widest font-bold">
                QR Code Pix
              </div>
            </div>

            <div className="space-y-3">
              <p className="text-xs uppercase tracking-widest" style={{ color: "oklch(0.50 0.02 260)" }}>
                copie a chave pix (e-mail)
              </p>
              <div 
                className="flex items-center gap-2 p-3 rounded-xl border"
                style={{ background: "oklch(0.12 0.015 260)", borderColor: "oklch(0.22 0.02 260)" }}
              >
                <code className="flex-1 text-xs text-zinc-200 truncate font-mono">
                  {pixSettings?.pixKey || "carregando..."}
                </code>
                <button 
                  onClick={copyPix}
                  className="px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-colors"
                  style={{ background: "oklch(0.72 0.12 280)", color: "oklch(0.09 0.01 260)" }}
                >
                  copiar
                </button>
              </div>
            </div>

            <div 
              className="p-4 rounded-xl text-xs leading-relaxed"
              style={{ background: "oklch(0.14 0.015 260)", color: "oklch(0.55 0.02 260)" }}
            >
              após o pagamento, clique no botão abaixo. nossa equipe ativará sua licença em até 24h.
            </div>

            <button
              onClick={() => {
                toast.success("avisamos o administrador. aguarde a ativação.");
                navigate("/chat");
              }}
              className="w-full py-3.5 rounded-full text-sm border transition-all"
              style={{ borderColor: "oklch(0.30 0.03 280)", color: "oklch(0.72 0.12 280)" }}
            >
              já realizei o pagamento
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
