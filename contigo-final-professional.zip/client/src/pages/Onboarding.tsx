import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { PERSONALITIES, type PersonalitySlug } from "@/lib/personalities";
import { useState } from "react";
import { useLocation } from "wouter";

type Step = "name" | "personality";

export default function Onboarding() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [step, setStep] = useState<Step>("name");
  const [displayName, setDisplayName] = useState("");
  const [age, setAge] = useState("");
  const [selectedPersonality, setSelectedPersonality] = useState<PersonalitySlug>("vicente");
  const [nameError, setNameError] = useState("");

  const completeMutation = trpc.onboarding.complete.useMutation({
    onSuccess: () => navigate("/chat"),
  });

  function handleNameSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = displayName.trim();
    const ageNum = parseInt(age);
    if (!trimmed) { setNameError("como posso te chamar?"); return; }
    if (!age || isNaN(ageNum) || ageNum < 13 || ageNum > 120) {
      setNameError("preciso da sua idade (entre 13 e 120)");
      return;
    }
    setNameError("");
    setStep("personality");
  }

  function handleComplete() {
    completeMutation.mutate({
      displayName: displayName.trim(),
      age: parseInt(age),
      activePersonality: selectedPersonality,
    });
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-6 relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 40%, oklch(0.18 0.04 280 / 0.2) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 w-full max-w-md">
        {step === "name" && (
          <form onSubmit={handleNameSubmit} className="flex flex-col gap-8">
            <div className="text-center">
              <p
                className="text-3xl font-normal mb-2"
                style={{ fontFamily: "'Lora', serif", color: "oklch(0.92 0.01 260)" }}
              >
                antes de começar
              </p>
              <p className="text-sm" style={{ color: "oklch(0.55 0.02 260)" }}>
                quero te conhecer um pouco
              </p>
            </div>

            <div className="flex flex-col gap-5">
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest" style={{ color: "oklch(0.50 0.02 260)" }}>
                  como posso te chamar?
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="seu nome ou apelido"
                  className="w-full bg-transparent border-b py-3 text-lg outline-none transition-colors placeholder:text-muted-foreground/40"
                  style={{
                    borderColor: "oklch(0.30 0.03 280)",
                    color: "oklch(0.92 0.01 260)",
                    fontFamily: "'Lora', serif",
                  }}
                  autoFocus
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest" style={{ color: "oklch(0.50 0.02 260)" }}>
                  quantos anos você tem?
                </label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="sua idade"
                  min={13}
                  max={120}
                  className="w-full bg-transparent border-b py-3 text-lg outline-none transition-colors placeholder:text-muted-foreground/40"
                  style={{
                    borderColor: "oklch(0.30 0.03 280)",
                    color: "oklch(0.92 0.01 260)",
                    fontFamily: "'Lora', serif",
                  }}
                />
              </div>

              {nameError && (
                <p className="text-sm" style={{ color: "oklch(0.65 0.18 25)" }}>
                  {nameError}
                </p>
              )}
            </div>

            <button
              type="submit"
              className="py-3.5 rounded-full text-sm font-medium transition-all duration-300"
              style={{
                background: "oklch(0.72 0.12 280)",
                color: "oklch(0.09 0.01 260)",
                boxShadow: "0 0 20px oklch(0.72 0.12 280 / 0.3)",
              }}
            >
              continuar
            </button>
          </form>
        )}

        {step === "personality" && (
          <div className="flex flex-col gap-8">
            <div className="text-center">
              <p
                className="text-3xl font-normal mb-2"
                style={{ fontFamily: "'Lora', serif", color: "oklch(0.92 0.01 260)" }}
              >
                quem você quer por perto?
              </p>
              <p className="text-sm" style={{ color: "oklch(0.55 0.02 260)" }}>
                você pode mudar isso a qualquer momento
              </p>
            </div>

            <div className="flex flex-col gap-3 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
              {PERSONALITIES.map((p) => (
                <button
                  key={p.slug}
                  onClick={() => setSelectedPersonality(p.slug)}
                  className="w-full text-left p-4 rounded-xl border transition-all duration-200 relative overflow-hidden"
                  style={{
                    borderColor:
                      selectedPersonality === p.slug
                        ? p.accentColor
                        : "oklch(0.22 0.02 260)",
                    background:
                      selectedPersonality === p.slug
                        ? `${p.accentColor}18`
                        : "oklch(0.12 0.015 260)",
                    boxShadow:
                      selectedPersonality === p.slug
                        ? `0 0 20px ${p.accentColor}25`
                        : "none",
                  }}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-xl mt-0.5">{p.emoji}</span>
                    <div className="flex flex-col gap-0.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span
                          className="font-medium text-sm"
                          style={{ color: selectedPersonality === p.slug ? p.accentColor : "oklch(0.85 0.01 260)" }}
                        >
                          {p.name}
                        </span>
                        <span className="text-[10px] uppercase tracking-tighter" style={{ color: "oklch(0.45 0.02 260)" }}>
                          {p.subTitle}
                        </span>
                      </div>
                      <p className="text-xs leading-relaxed" style={{ color: "oklch(0.60 0.02 260)" }}>
                        {p.description}
                      </p>
                      <p className="text-[10px] italic mt-1" style={{ color: "oklch(0.45 0.02 260)" }}>
                        Ideal {p.useCase}
                      </p>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <button
              onClick={handleComplete}
              disabled={completeMutation.isPending}
              className="py-3.5 rounded-full text-sm font-medium transition-all duration-300 disabled:opacity-50"
              style={{
                background: "oklch(0.72 0.12 280)",
                color: "oklch(0.09 0.01 260)",
                boxShadow: "0 0 20px oklch(0.72 0.12 280 / 0.3)",
              }}
            >
              {completeMutation.isPending ? "entrando..." : "começar"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
