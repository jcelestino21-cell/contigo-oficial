import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

type Tab = "users" | "subscriptions";

export default function Admin() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const [tab, setTab] = useState<Tab>("users");

  useEffect(() => {
    if (!loading && (!isAuthenticated || user?.role !== "admin")) {
      navigate("/");
    }
  }, [loading, isAuthenticated, user, navigate]);

  const usersQuery = trpc.admin.users.useQuery({ limit: 100, offset: 0 }, { enabled: user?.role === "admin" });
  const subsQuery = trpc.admin.subscriptions.useQuery({ limit: 100, offset: 0 }, { enabled: user?.role === "admin" });

  const overrideMutation = trpc.admin.overrideSubscription.useMutation({
    onSuccess: () => { toast.success("Status atualizado."); subsQuery.refetch(); },
    onError: () => toast.error("Erro ao atualizar."),
  });

  const rolesMutation = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => { toast.success("Papel atualizado."); usersQuery.refetch(); },
    onError: () => toast.error("Erro ao atualizar papel."),
  });

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-5 h-5 rounded-full border border-muted-foreground/20 border-t-primary animate-spin" />
      </div>
    );
  }

  if (user.role !== "admin") return null;

  const statusColors: Record<string, string> = {
    active: "#5B9E8A",
    trialing: "#4A90D9",
    overdue: "#E8A838",
    canceled: "#C0392B",
    free: "oklch(0.45 0.02 260)",
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div
        className="flex items-center justify-between px-6 py-4 border-b"
        style={{ borderColor: "oklch(0.18 0.02 260)" }}
      >
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/chat")} style={{ color: "oklch(0.50 0.02 260)" }}>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-lg font-medium" style={{ fontFamily: "'Lora', serif", color: "oklch(0.92 0.01 260)" }}>
            painel admin
          </h1>
        </div>
        <span className="text-xs px-2 py-1 rounded-full" style={{ background: "oklch(0.72 0.12 280 / 0.15)", color: "oklch(0.72 0.12 280)" }}>
          admin
        </span>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 px-6 py-4">
        {[
          { label: "usuários", value: usersQuery.data?.length ?? "—" },
          { label: "assinaturas", value: subsQuery.data?.length ?? "—" },
          { label: "premium", value: subsQuery.data?.filter((s) => s.status === "active" || s.status === "trialing").length ?? "—" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-xl p-4 border text-center"
            style={{ background: "oklch(0.12 0.015 260)", borderColor: "oklch(0.22 0.02 260)" }}
          >
            <p className="text-2xl font-light" style={{ color: "oklch(0.92 0.01 260)" }}>
              {stat.value}
            </p>
            <p className="text-xs mt-1" style={{ color: "oklch(0.50 0.02 260)" }}>
              {stat.label}
            </p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex px-6 gap-1 border-b" style={{ borderColor: "oklch(0.18 0.02 260)" }}>
        {(["users", "subscriptions"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="px-4 py-2.5 text-sm border-b-2 transition-colors"
            style={{
              borderColor: tab === t ? "oklch(0.72 0.12 280)" : "transparent",
              color: tab === t ? "oklch(0.85 0.01 260)" : "oklch(0.50 0.02 260)",
            }}
          >
            {t === "users" ? "usuários" : "assinaturas"}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {tab === "users" && (
          <div className="flex flex-col gap-2">
            {usersQuery.isLoading && (
              <div className="flex justify-center py-8">
                <div className="w-5 h-5 rounded-full border border-muted-foreground/20 border-t-primary animate-spin" />
              </div>
            )}
            {usersQuery.data?.map((u) => (
              <div
                key={u.id}
                className="flex items-center justify-between p-4 rounded-xl border"
                style={{ background: "oklch(0.12 0.015 260)", borderColor: "oklch(0.22 0.02 260)" }}
              >
                <div>
                  <p className="text-sm font-medium" style={{ color: "oklch(0.88 0.01 260)" }}>
                    {u.displayName ?? u.name ?? "—"}
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: "oklch(0.50 0.02 260)" }}>
                    {u.email ?? "sem email"} · {u.role}
                  </p>
                  <p className="text-xs" style={{ color: "oklch(0.40 0.02 260)" }}>
                    desde {new Date(u.createdAt).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <div className="flex gap-2">
                  {u.role === "user" ? (
                    <button
                      onClick={() => rolesMutation.mutate({ userId: u.id, role: "admin" })}
                      className="text-xs px-2.5 py-1 rounded-lg border transition-colors"
                      style={{ borderColor: "oklch(0.30 0.03 280)", color: "oklch(0.72 0.12 280)" }}
                    >
                      tornar admin
                    </button>
                  ) : (
                    <button
                      onClick={() => rolesMutation.mutate({ userId: u.id, role: "user" })}
                      className="text-xs px-2.5 py-1 rounded-lg border transition-colors"
                      style={{ borderColor: "oklch(0.30 0.03 260)", color: "oklch(0.55 0.02 260)" }}
                    >
                      remover admin
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "subscriptions" && (
          <div className="flex flex-col gap-2">
            {subsQuery.isLoading && (
              <div className="flex justify-center py-8">
                <div className="w-5 h-5 rounded-full border border-muted-foreground/20 border-t-primary animate-spin" />
              </div>
            )}
            {subsQuery.data?.map((sub) => (
              <div
                key={sub.id}
                className="flex items-center justify-between p-4 rounded-xl border"
                style={{ background: "oklch(0.12 0.015 260)", borderColor: "oklch(0.22 0.02 260)" }}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className="text-xs px-2 py-0.5 rounded-full font-medium"
                      style={{
                        background: `${statusColors[sub.status] ?? "oklch(0.45 0.02 260)"}20`,
                        color: statusColors[sub.status] ?? "oklch(0.55 0.02 260)",
                      }}
                    >
                      {sub.status}
                    </span>
                    <span className="text-xs" style={{ color: "oklch(0.50 0.02 260)" }}>
                      user #{sub.userId}
                    </span>
                  </div>
                  {sub.currentPeriodEnd && (
                    <p className="text-xs mt-1" style={{ color: "oklch(0.45 0.02 260)" }}>
                      expira: {new Date(sub.currentPeriodEnd).toLocaleDateString("pt-BR")}
                    </p>
                  )}
                  {sub.stripeCustomerId && (
                    <p className="text-xs" style={{ color: "oklch(0.35 0.02 260)" }}>
                      {sub.stripeCustomerId.slice(0, 20)}…
                    </p>
                  )}
                </div>
                <div className="flex flex-col gap-1">
                  <button
                    onClick={() => overrideMutation.mutate({ userId: sub.userId, status: "active" })}
                    className="text-xs px-2.5 py-1 rounded-lg border transition-colors"
                    style={{ borderColor: "#5B9E8A40", color: "#5B9E8A" }}
                  >
                    liberar
                  </button>
                  <button
                    onClick={() => overrideMutation.mutate({ userId: sub.userId, status: "canceled" })}
                    className="text-xs px-2.5 py-1 rounded-lg border transition-colors"
                    style={{ borderColor: "#C0392B40", color: "#C0392B" }}
                  >
                    bloquear
                  </button>
                </div>
              </div>
            ))}
            {subsQuery.data?.length === 0 && (
              <p className="text-center py-8 text-sm" style={{ color: "oklch(0.45 0.02 260)" }}>
                nenhuma assinatura ainda.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
