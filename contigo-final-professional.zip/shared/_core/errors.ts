/**
 * Estrutura padrão de erro para a API Contigo.
 * Profissionaliza o debug e a comunicação com o frontend.
 */
export interface ErrorResponse {
  error: {
    code: string;    // Ex: "UNAUTHORIZED", "INVALID_KEY", "LICENSE_EXPIRED"
    message: string; // Mensagem amigável para o usuário
    internalCode?: number; // Códigos legados ou específicos (10001, 10002)
  };
}

/**
 * Base HTTP error class with status code and error codes.
 * Throw this from route handlers to send specific HTTP errors.
 */
export class HttpError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string,
    public internalCode?: number
  ) {
    super(message);
    this.name = "HttpError";
  }

  /**
   * Converte o erro para o formato de resposta padrão da API.
   */
  toJSON(): ErrorResponse {
    return {
      error: {
        code: this.code,
        message: this.message,
        internalCode: this.internalCode,
      },
    };
  }
}

// Convenience constructors atualizados
export const BadRequestError = (msg: string, code = "BAD_REQUEST", internalCode?: number) => 
  new HttpError(400, code, msg, internalCode);

export const UnauthorizedError = (msg: string, code = "UNAUTHORIZED", internalCode?: number) => 
  new HttpError(401, code, msg, internalCode);

export const ForbiddenError = (msg: string, code = "FORBIDDEN", internalCode?: number) => 
  new HttpError(403, code, msg, internalCode);

export const NotFoundError = (msg: string, code = "NOT_FOUND", internalCode?: number) => 
  new HttpError(404, code, msg, internalCode);
