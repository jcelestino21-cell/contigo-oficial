# Configuração do Stripe — Contigo

## Dados do Proprietário
- **Nome**: J. Celestino
- **CPF**: 47186648886
- **Email**: jcelestino21@gmail.com
- **Banco**: Mercado Pago
- **Agência**: 0001
- **Conta**: 89842816190

## Próximos Passos para Configurar o Stripe

### 1. Criar Conta no Stripe
1. Acesse [stripe.com/br](https://stripe.com/br)
2. Clique em "Começar"
3. Preencha com os dados acima
4. Verifique seu email

### 2. Configurar Produto e Preço
1. No dashboard do Stripe, vá para **Products**
2. Clique em **+ Add product**
3. Preencha:
   - **Name**: Contigo Premium
   - **Description**: Acesso ilimitado a todas as 5 personalidades
   - **Price**: R$ 5,00
   - **Billing period**: Monthly
4. Copie o **Price ID** (começa com `price_`)

### 3. Configurar Webhook
1. Vá para **Developers** → **Webhooks**
2. Clique em **+ Add endpoint**
3. URL do webhook: `https://seu-dominio.com/api/stripe/webhook`
4. Selecione os eventos:
   - `checkout.session.completed`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
5. Copie o **Webhook Secret** (começa com `whsec_`)

### 4. Configurar Chaves de API
1. Vá para **Developers** → **API Keys**
2. Copie a **Secret Key** (começa com `sk_live_` ou `sk_test_`)

### 5. Adicionar Chaves ao Contigo
1. No painel de administração do Contigo, vá para **Settings** → **Payment**
2. Cole:
   - **STRIPE_SECRET_KEY**: Sua Secret Key
   - **STRIPE_WEBHOOK_SECRET**: Seu Webhook Secret
   - **STRIPE_PRICE_ID**: Seu Price ID

### 6. Configurar Transferências Bancárias
1. No Stripe, vá para **Settings** → **Bank accounts**
2. Adicione sua conta Mercado Pago:
   - Agência: 0001
   - Conta: 89842816190
3. O Stripe transferirá os pagamentos automaticamente

## Teste
- Use o cartão `4242 4242 4242 4242` para testar pagamentos
- Qualquer data futura e qualquer CVC funcionam

## Status Atual
- ✅ Backend pronto para receber pagamentos
- ✅ Webhooks configurados
- ✅ Painel admin com dashboard de receita
- ⏳ Aguardando configuração do Stripe (chaves de API)

## Suporte
Para dúvidas sobre Stripe, acesse: [stripe.com/docs](https://stripe.com/docs)
