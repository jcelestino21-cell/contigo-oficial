# Contigo — TODO

## Banco de Dados
- [x] Schema: tabela subscriptions
- [x] Schema: tabela messages
- [x] Schema: tabela personalities
- [x] Schema: campos adicionais em users (displayName, age, onboardingDone, activePersonality)
- [x] Migração gerada e aplicada

## Backend
- [x] Router: chat com IA (5 personalidades, prompt emocional, histórico)
- [x] Router: personalities (listar, selecionar)
- [x] Router: subscriptions (status, criar checkout Stripe, portal)
- [x] Router: admin (listar usuários, assinaturas, bloquear/liberar)
- [x] Webhook Stripe (pagamento aprovado, falhou, cancelado)
- [x] Middleware de acesso premium (verificar subscription ativa)
- [x] Onboarding (salvar nome, idade, personalidade escolhida)

## Frontend
- [x] Tema escuro intimista (CSS variables, fontes, cores)
- [x] Tela inicial (landing page com fundo preto, CTA de entrada)
- [x] Onboarding (coletar nome, idade, escolher personalidade)
- [x] Tela de chat emocional (estilo íntimo, "digitando...", delay variável)
- [x] Seleção de personalidade (cards com Noah, Vicente, Axel, Sol, Nico)
- [x] Tela de assinatura (plano free vs premium, checkout Stripe)
- [x] Painel admin (/admin — usuários, assinaturas, ações)
- [x] Rota protegida para usuários sem assinatura ativa
- [x] Histórico de conversa persistente entre sessões

## Integração
- [x] Stripe: checkout session, portal de cliente
- [x] Stripe: webhooks sincronizando status de assinatura
- [x] Stripe: STRIPE_PRICE_ID configurado (price_1TJbq4JMTtS1SSB0J0vSg9QJ)
- [x] Stripe: STRIPE_SECRET_KEY configurada
- [x] Stripe: STRIPE_WEBHOOK_SECRET configurada
- [x] OpenAI/LLM: motor de IA com prompts emocionais por personalidade
- [x] STRIPE_CONFIG.md: guia de configuração com dados do proprietário

## Testes
- [x] Teste: chat router (personalidade, resposta IA)
- [x] Teste: subscription router (status, acesso)
- [x] Teste: admin router (permissões)
- [x] Todos os 15 testes passando

## Melhorias Implementadas
- [x] Painel admin: dashboard de receita e analytics
- [x] Painel admin: histórico de transações Stripe
- [x] Painel admin: gráficos de assinantes e churn
- [x] Painel admin: MRR, LTV, taxa de conversão
- [x] PWA: manifest.json com ícones
- [x] PWA: service worker para offline
- [x] PWA: instalação no Android como app nativo
- [x] PWA: suporte a push notifications (pronto para implementar)
